# platform-game
A Platform Game in Pure JS 
https://eloquentjavascript.net/16_game.html

This is a platform game project written in pure JavaScript without any libraries / engine for learning purposes.

Taken from chapter 16 of 3rd Edition of Eloquent JavaScript https://eloquentjavascript.net by Marijn Haverbeke

<img alt="Game Screenshot" src="https://raw.githubusercontent.com/lavimalik/platform-game/master/img/game-screenshot.png" width="600" height="450" />
